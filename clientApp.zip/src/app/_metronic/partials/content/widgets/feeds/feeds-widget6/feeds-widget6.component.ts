import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feeds-widget6',
  templateUrl: './feeds-widget6.component.html',
})
export class FeedsWidget6Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
